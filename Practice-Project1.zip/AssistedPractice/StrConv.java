public class StrConv {
    public static void main(String[] args) {
        //created a string
        String s = "Simplilearn";
        StringBuffer strbuff = new StringBuffer(s);
        StringBuilder strbul = new StringBuilder(s);

        //Display
        System.out.println("String : " + s);
        System.out.println("StringBuffer: "+strbuff);
        System.out.println("StringBuilder: "+strbul);
        

    }
    
}
