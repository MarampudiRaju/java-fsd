public class ConstructorTypes {
    public static void main(String[] args) {
        A a =new A();
        new A(6,6,6);
        new A(a);
    }
}
class A
{
    //Default Constructor
    A()
    {
        int length=5;
        int breadth =5;
        int height =5;
        int Area =length*breadth*height;
        System.out.println("Area of Box is "+Area );
    }
    //Parametrized Constructor
    A(int l,int b,int h)
    {
        int Area = l*b*h;
        System.out.println("Area = "+ Area);
    }
    // copy Constructor
    A(A a)
    {
        System.out.println("This is copy Constructor");
    }
}
