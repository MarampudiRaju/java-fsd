public class CallingMethods {

    public static void main(String[] args) {
        CallingMethods cm = new CallingMethods();
 
         // Calling a method with no parameters and no return value
         cm.Message();
 
         // Calling a method with parameters and return value
         int Value = cm.Muliplication(78, 3);
         System.out.println("Answer = " + Value);
 
         // Calling a method with parameters and no return value
         cm.Name("Raju");
     }
   
        // Method with no parameters and no return value
        public void Message() {
            System.out.println("HelloWorld!");
        }
    
        // Method with parameters and return value
        public int Muliplication(int a, int b) {
            return a * b;
        }
    
        // Method with parameters and no return value
        public void Name(String name) {
            System.out.println( name);
        }

    }
