public class Arrays {
    public static void main(String[] args) {
        // Array of integers Type
        int[] arr = {10, 20, 30, 40, 50};
        // Array of String Type
        String[] names = new String[3];
        names[0] = "John";
        names[1] = "Mary";
        names[2] = "Peter";
        for(int i=0;i<arr.length;i++)
        {
            System.out.print(arr[i]+" ");
        }
        System.out.println("\nNames: ");
        for(String n:names)
        {
            System.out.print(n+" ");
        }
    }
}
