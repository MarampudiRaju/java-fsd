//outer class
class external
{
    public external()
    {
        System.out.println("Hello, from Outter class");
    }
    // Inner class
    class internal
    {
        public internal()
        {
            System.out.println("Hi, from inner class");
        }
    }
    public static void main(String[] args) {
        external e = new external();
        e.new internal();
    }
}