 public class TypeCasting {
    public static void main(String[] args) {
        // Implicit typecasting
        int num = 10;
        double myDouble = num; // Implicitly casting int to double
        System.out.println("Implicit Typecasting:");
        System.out.println("num: " + num);
        System.out.println("myDouble: " + myDouble);

        // Explicit typecasting
        double c = 7.5;
        int d = (int) c; // Explicitly casting double to int
        System.out.println("\nExplicit Typecasting:");
        System.out.println("anotherDouble: " + c);
        System.out.println("anotherInt: " + d);
    }
    
}
