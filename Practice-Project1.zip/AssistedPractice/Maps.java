
    import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Maps {
    public static void main(String[] args) {
        // HashMap
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Apple", 10);
        hashMap.put("Banana", 20);
        hashMap.put("Orange", 30);
        System.out.println("HashMap: " + hashMap);

        // TreeMap
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Apple", 10);
        treeMap.put("Banana", 20);
        treeMap.put("Orange", 30);
        System.out.println("TreeMap: " + treeMap);

        // Accessing elements in the map
        int appleValue = hashMap.get("Apple");
        System.out.println("Value of Apple in HashMap: " + appleValue);

        int bananaValue = treeMap.get("Banana");
        System.out.println("Value of Banana in TreeMap: " + bananaValue);

        // Checking if an element exists
        boolean containsOrange = hashMap.containsKey("Orange");
        System.out.println("HashMap contains Orange: " + containsOrange);

        boolean containsGrapes = treeMap.containsKey("Grapes");
        System.out.println("TreeMap contains Grapes: " + containsGrapes);

        // Removing an element
        hashMap.remove("Apple");
        System.out.println("HashMap after removing Apple: " + hashMap);
    }
}

