
public class AccessModifiers {

      public static void main(String[] args) {
        AccessModifiers obj = new AccessModifiers();
  
        // Accessing methods
        obj.privateMethod();
        obj.protectedMethod();
        obj.defaultMethod();
        obj.publicMethod();
    }
    private void privateMethod() {
        System.out.println("This is Private method can access only within the same class");
    }
    
    protected void protectedMethod() {
        System.out.println(" This is Protected method can access within the package and other package of sub classes");
    }
    
    void defaultMethod() {
        System.out.println("This is Default method can access within the same package");
    }
    
    public void publicMethod() {
        System.out.println("This is Public method can access in any package");
    }
    
}
