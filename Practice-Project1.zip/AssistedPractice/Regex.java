import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex {
    public static void main(String[] args) {
        String num="7995643507";
        String pattern = "^[7-9]\\d{9}$";
       Pattern  p = Pattern.compile(pattern);
       Matcher  m = p.matcher(num);
       if(m.matches()) System.out.println("Valid");
       else System.out.println("Not Valid");

    }
}
