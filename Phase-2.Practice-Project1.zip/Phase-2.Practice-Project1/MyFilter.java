import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter("/myservlet")
 class MyFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization logic
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        // Pre-processing logic

        // Perform filtering or modification on the request/response if needed
        request.setAttribute("message", "This message is added by the filter");

        // Pass the request and response to the next filter or servlet in the chain
        chain.doFilter(request, response);

        // Post-processing logic
    }

    @Override
    public void destroy() {
        // Cleanup logic
    }
}
