import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/session")
public class SessionTrackingServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the session object from the request
        HttpSession session = request.getSession();

        // Retrieve the session ID from the session object
        String sessionId = session.getId();

        // Check if the session already has a visitedCount attribute
        Integer visitedCount = (Integer) session.getAttribute("visitedCount");
        if (visitedCount == null) {
            // If the attribute doesn't exist, set it to 1
            visitedCount = 1;
        } else {
            // If the attribute exists, increment its value by 1
            visitedCount++;
        }

        // Set the visitedCount attribute in the session
        session.setAttribute("visitedCount", visitedCount);

        // Create a cookie to store the session ID
        Cookie sessionCookie = new Cookie("sessionId", sessionId);
        sessionCookie.setMaxAge(60 * 60 * 24 * 7); // Cookie expiration time (7 days)
        response.addCookie(sessionCookie);

        // Set the response content type
        response.setContentType("text/html");

        // Create the response HTML
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Session Tracking Example</h1>");
        out.println("<p>Session ID: " + sessionId + "</p>");
        out.println("<p>Visited Count: " + visitedCount + "</p>");
        out.println("</body></html>");
    }
}
