import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/session")
 class SessionTrackingServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the session object from the request
        HttpSession session = request.getSession();

        // Retrieve the session ID from the session object
        String sessionId = session.getId();

        // Check if the session already has a visitedCount attribute
        Integer visitedCount = (Integer) session.getAttribute("visitedCount");
        if (visitedCount == null) {
            // If the attribute doesn't exist, set it to 1
            visitedCount = 1;
        } else {
            // If the attribute exists, increment its value by 1
            visitedCount++;
        }

        // Set the visitedCount attribute in the session
        session.setAttribute("visitedCount", visitedCount);

        // Set the response content type
        response.setContentType("text/html");

        // Create the response HTML
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Session Tracking Example</h1>");
        out.println("<form action=\"session\" method=\"post\">");
        out.println("<input type=\"hidden\" name=\"sessionId\" value=\"" + sessionId + "\">");
        out.println("<p>Session ID: " + sessionId + "</p>");
        out.println("<p>Visited Count: " + visitedCount + "</p>");
        out.println("<input type=\"submit\" value=\"Refresh\">");
        out.println("</form>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the session object from the request
        HttpSession session = request.getSession();

        // Retrieve the session ID from the hidden form field
        String sessionId = request.getParameter("sessionId");

        // Set the session ID in the session object
        session.setId(sessionId);

        // Redirect the user back to the GET request
        response.sendRedirect("session");
    }
}
