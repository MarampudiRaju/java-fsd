import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the username and password from the request parameters
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Check if the username and password are valid (dummy validation)
        if (isValidCredentials(username, password)) {
            // Create a new session or retrieve the existing session
            HttpSession session = request.getSession();

            // Set the "username" attribute in the session
            session.setAttribute("username", username);

            // Redirect the user to the home page
            response.sendRedirect("home");
        } else {
            // If the credentials are invalid, show an error message
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h1>Login Failed</h1>");
            out.println("<p>Invalid username or password. Please try again.</p>");
            out.println("</body></html>");
        }
    }

    private boolean isValidCredentials(String username, String password) {
        // Dummy validation - check if the username and password match
        return username.equals("admin") && password.equals("admin123");
    }
}

@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Invalidate the current session
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }

        // Redirect the user to the login page
        response.sendRedirect("login");
    }
}

@WebServlet("/home")
public class HomeServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve the session object from the request
        HttpSession session = request.getSession(false);

        // Check if the user is logged in (session exists and contains "username" attribute)
        if (session != null && session.getAttribute("username") != null) {
            // Get the username from the session
            String username = (String) session.getAttribute("username");

            // Set the response content type
            response.setContentType("text/html");

            // Create the response HTML
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h1>Welcome, " + username + "!</h1>");
            out.println("<p><a href=\"logout\">Logout</a></p>");
            out.println("</body></html>");
        } else {
            // If the user is not logged in, redirect to the login page
            response.sendRedirect("login");
        }
    }
}
