import java.util.*;
public class RotateArray
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int rotationSteps = 5;
        System.out.println("Enter size of an Array:");
        int n =sc.nextInt();
        int arr[] = new int[n];
        System.out.println("Enter Elements of Array");
        for(int i=0;i<n;i++)
        {
            arr[i]=sc.nextInt();
        }
        System.out.println("Array before rotation:");
        for(int array:arr)
        {
            System.out.print(array+" ");
        }
        System.out.println();
        System.out.println("Array after Rotation:");
        rotateArray(arr,rotationSteps);
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
        sc.close();
       
    }

    public static void rotateArray(int[] arr, int steps) {
        int length = arr.length;
        steps = steps % length;
        reverseArray(arr, 0, length - 1);
        reverseArray(arr, 0, steps - 1);
        reverseArray(arr, steps, length - 1); 
        reverseArray(arr, 0, length - 1);
        reverseArray(arr, 0, steps - 1);
    }

    public static void reverseArray(int[] arr, int start, int end) {
        while (start < end) {
            int temp = arr[start];
            arr[start] = arr[end];
            arr[end] = temp;
            start++;
            end--;
        }
    }
}