import java.util.Arrays;

public class FourthSmallest {
    public static void main(String[] args) {
        int arr [] = {45,32,12,98,6,23,2};
        Arrays.sort(arr);
        System.out.println("Fourth Smallest number in Array is: "+arr[3]);
    }
}
