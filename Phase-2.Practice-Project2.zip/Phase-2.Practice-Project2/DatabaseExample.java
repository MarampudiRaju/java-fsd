package com.productdb;

import java.sql.*;

public class DatabaseExample {
    // JDBC driver name and database URL
    static final String DB_URL = "jdbc:mysql://localhost:3306/";

    // Database credentials
    static final String USER = "root";
    static final String PASS = "root";

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        Statement stmt = null;
            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Create a database
            System.out.println("Creating database...");
            stmt = conn.createStatement();
            String sql = "CREATE DATABASE testdb";
            stmt.executeUpdate(sql);
            System.out.println("Database created successfully!");

            // Select the database
            System.out.println("Selecting database...");
            conn.setCatalog("testdb");
            System.out.println("Database selected successfully!");

            // Drop the database
            System.out.println("Dropping database...");
            sql = "DROP DATABASE testdb";
            stmt.executeUpdate(sql);
            System.out.println("Database dropped successfully!");

      
                if (stmt != null)
                    stmt.close();
        
                if (conn != null)
                    conn.close();
    }
}