import java.sql.*;

public class StoredProcExample {
    // JDBC driver and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/testdb";

    // Database credentials
    static final String USER = "root";
    static final String PASS = "root";

    public static void main(String[] args) {
        Connection conn = null;
        CallableStatement stmt = null;

        try {
            // Register JDBC driver
            Class.forName(JDBC_DRIVER);

            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Create a callable statement for the stored procedure
            String callProc = "{call sp_increase_salary(?, ?)}";
            stmt = conn.prepareCall(callProc);

            // Set input parameters for the stored procedure
            stmt.setInt(1, 1001); // employee ID
            stmt.setDouble(2, 5000.00); // salary increment

            // Execute the stored procedure
            System.out.println("Calling stored procedure...");
            stmt.execute();
            System.out.println("Stored procedure executed successfully.");

            // Clean-up
            stmt.close();
            conn.close();
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
    }
}
