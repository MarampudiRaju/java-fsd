package com.productdb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class IUD {
	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
			while(true) {
			System.out.println("1.To Create Table\n2.Insert rows to Table\n3.Update Data\n4.Delete Row\n5.Exit");
		System.out.println("Enter choice: ");
		int choice = sc.nextInt();
		switch(choice)
		{
		case 1:
			createTable();
			System.out.println("Table Created Successfully!");
			break;
		case 2:
			insertvalues();
			System.out.println("Values Inserted into table succesfully");
			break;
		case 3:
			UpdateData();
			System.out.println("Updated successfully!!");
			break;
		case 4:
			DeleteData();
			System.out.println("Deleted successfully!");
			break;
		case 5:System.exit(0);
		break;			
		   }
		}
	
}
	public static Connection getcon() throws SQLException
	{
		String username="root";
		String password = "root";
		String url = "jdbc:mysql://localhost:3306/testdb";
		Connection con = DriverManager.getConnection(url,username,password);
		return con;

	}
	public static void createTable() throws SQLException
	{
		String query ="Create table employee(EmpID varchar(10), Name varchar(50), salary int)";
		Statement st =getcon().createStatement();
		st.executeUpdate(query);	
	}
	public static void insertvalues() throws SQLException
	{
		Statement st =getcon().createStatement();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter EmployeeID: ");
		String id=sc.nextLine();
		System.out.println("Enter Employee Name: ");
		String Name=sc.nextLine();
		System.out.println("Enter Employee salary: ");
		int sal=sc.nextInt();
		String query="insert into employee values("+"'id'"+","+"'Name'"+","+sal+")";
		st.executeUpdate(query);

	}
	public static void UpdateData() throws SQLException
	{
		Statement st =getcon().createStatement();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter EmployeeID: ");
		String Id=sc.nextLine();
		System.out.println("Enter Employee Name to change: ");
		String name=sc.nextLine();
	    String query = "update employee set Name="+"'name'"+"where EmpID="+"'Id'";
		st.executeUpdate(query);
	
	}
	public static void DeleteData() throws SQLException
	{
		Statement st =getcon().createStatement();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter EmployeeID to delete record: ");
		String id=sc.nextLine();
		String query = "Delete  from employee where EmpID="+"'id'";
		st.executeUpdate(query);
	
	}
	
	

}
