class Circle {
  
    private double radius;
    
    public Circle(double radius) {
        this.radius = radius;
    }
    
    public double calculateArea() {
          return Math.PI * radius * radius;
    }

    public double getRadius() {
        return radius;
    }
}

// Main class
public class Oops {
    public static void main(String[] args) {
        // Creating objects of the Circle class
        Circle circle1 = new Circle(5.0);
        Circle circle2 = new Circle(6.0);
        
        System.out.println("Circle 1: Radius = " + circle1.getRadius());
        System.out.println("Circle 1: Area = " + circle1.calculateArea());
        
        System.out.println("Circle 2: Radius = " + circle2.getRadius());
        System.out.println("Circle 2: Area = " + circle2.calculateArea());
    }
}
