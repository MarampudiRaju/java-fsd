import java.io.File;
import java.io.IOException;

public class ThrowThrowsFinally {
   public static void main(String[] args) throws IOException {
    try {
        // Throw an object of user defined exception
        throw new MyException();
    }
    catch (MyException ex) {
        System.out.println("Caught");
        System.out.println(ex.getMessage());
    }
    finally{
        System.out.println("This is Finally Block To Print Some message");
    }
    CreateFile.Create();
  
   }
}

class MyException extends Exception {
}

class CreateFile
{
    //Throws keyword at Method
    public static void Create() throws IOException
    {
        File f = new File("file.txt");
        if(f.createNewFile())
        System.out.println("File Created Successfully");
        else
        System.out.println("File Already Exists");
    }
}
