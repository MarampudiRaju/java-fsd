import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
class CRUDFile{
    public static void main(String[] args) throws IOException {
        String Path ="C:\\Java Programs\\Stringcodes\\file.txt";
        CreateFile.Create(Path);
        WriteFile.Write(Path);
        ReadFile.Read(Path);
        DeleteFile.Delete(Path);
        UpdateFile.Update();
        
    }
}
class CreateFile
{
    public static void Create(String Path) throws IOException
    {
        File f = new File(Path);
        if(f.createNewFile())
        System.out.println("File Created Successfully");
        else
        System.out.println("File Already Exists");
    }
}
class WriteFile
{
    public static void Write(String Path) throws IOException
    {
        FileWriter w = new FileWriter(Path);
        w.write("Hello World");
        w.close();
    }
}

class ReadFile
{
    public static void Read(String Path) throws IOException
    {
        FileReader r = new FileReader(Path);
        int i = r.read();
        while(i!=-1)
        {
            System.out.print((char)i);
            i=r.read();
        }
        r.close();
    }
}
class DeleteFile
{
    public static void Delete(String Path)
    {
        File f = new File(Path);
        if(f.delete())
        System.out.println("File Delted "+ f.getName());
        else
        System.out.println("File Already Deleted");
    }
}
class UpdateFile {
    public static void Update() {
        String Path="C:\\Java Programs\\Stringcodes\\palindrome.java";
        try {
           
            FileReader fileReader = new FileReader(Path);
            BufferedReader bufferedReader = new BufferedReader(fileReader);

        StringBuilder contentBuilder = new StringBuilder();
        String line;
        while ((line = bufferedReader.readLine()) != null) {
        
            String modifiedLine = line.toUpperCase();
            contentBuilder.append(modifiedLine).append("\n");
        }
        bufferedReader.close();

      
        FileWriter fileWriter = new FileWriter(Path);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

        bufferedWriter.write(contentBuilder.toString());
        bufferedWriter.close();

        System.out.println("File updated successfully.");
    } catch (IOException e) {
        System.out.println("An error occurred while updating the file: " + e.getMessage());
    }
  }
}
