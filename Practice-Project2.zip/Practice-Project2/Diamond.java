interface Animal {
    default void sound() {
        System.out.println("Animal makes a sound");
    }
}

interface Dog extends Animal {
    default void sound() {
        System.out.println("Dog barks");
    }
}

interface Cat extends Animal {
    default void sound() {
        System.out.println("Cat meows");
    }
}

class AnimalHybrid implements Dog, Cat {
    public void sound() {
        Dog.super.sound(); // Call sound() method from Dog interface
        Cat.super.sound(); // Call sound() method from Cat interface
    }
}

public class Diamond {
    public static void main(String[] args) {
        AnimalHybrid animalHybrid = new AnimalHybrid();
        animalHybrid.sound();
    }
}
