// class MyRunnabel implements Runnable {
//     public void run()
//     {
//         for(int i =0;i<=10;i++)
//         {
//             System.out.print(i+" ");
//         }
//     }
// }

// class MyThread extends Thread
// {
//     public void run()
//     {
//         for(char c =97;c<=122;c++)
//         {
//             System.out.print(c + " ");
//         }
//     }
// }

// class ThreadImp extends Thread {
//    public static void main(String[] args) {
//     MyRunnabel r = new MyRunnabel();
//     MyThread t1 = new MyThread();
//     Thread t2 = new Thread(r);
//     t1.start();
//     t2.start();


//   }
// }





import java.io.*;
public class ThreadImp
{
    public static void main(String[] args) throws IOException {
        File f = new File("oops.java");
        if(f.createNewFile()) System.out.println("File Created");
        else System.out.println("FileName Already Exists");
    }
}