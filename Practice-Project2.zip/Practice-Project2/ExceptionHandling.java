class Array
{
    public static void main(String[] args) {
        int arr [] = {1,2,3,4,5};
        int index =5;
        //ArrayIndexOutOfBoundsException
        try{
        int result = arr[index];
        System.out.println(result);
        }catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("Please Provide Correct index within the range");
            
        }
        catch(Exception e)
        {
            System.out.println("Error"+ e.getMessage());
        }
        finally{
            System.out.println("Program Execution Completed");
        }
    }
}