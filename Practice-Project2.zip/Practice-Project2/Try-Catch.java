import java.util.Scanner;
class TryCatch{
   public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter a num: ");
      int a =sc.nextInt();
      System.out.print("Enter a num: ");
      int b =sc.nextInt();
      // try and catch 
      try{
      // this expression gives  Runtime error when user gives non-zero value
      int c=a/b;
      System.out.println(c);
      }catch(ArithmeticException e)
      {
        System.out.println("Exception Handled" + e.getMessage());
      }
      finally{
        sc.close();
      }
      
   }
}