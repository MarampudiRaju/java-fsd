class Sleep_Wait
{
    static Object obj = new Object();
    public static void main(String[] args) {
        Sleep s = new Sleep();
        s.start();
        System.out.println("Waiting Mode");
        synchronized(obj){
  
            try{
                obj.wait(2000);
                }catch(InterruptedException e)
                {
                    e.printStackTrace();
                }
            
            System.out.println("Waiting Over");
            } 
        }
    }

class Sleep extends Thread
{
    public void run()
    {
        System.out.println("Sleeping Mode");
        try{
            Thread.sleep(1000);
            }catch(InterruptedException e)
            {
                e.printStackTrace();
            }
        System.out.println("Sleeping over");

    }
}