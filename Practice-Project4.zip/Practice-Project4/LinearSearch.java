import java.util.*;
class LinearSearch
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        System.out.print("Enter number to search: ");
        int key = sc.nextInt();
       int index=Linearsearch(arr, key);
       if(index==-1)
       {
        System.out.println("Number not Found!");
       }
       else{System.out.println("Number found at index:"+ index);}
       sc.close();
    }
    public static int Linearsearch(int []arr,int key)
    {
        int flag=-1;
        for(int i=0;i<arr.length;i++)
        {
            if(key==arr[i]){
               flag=i;
                break;
            }
            else{continue;}
        }
        return flag;
    }
}
