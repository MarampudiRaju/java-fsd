import java.util.*;
public class BinarySearch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] arr = {91, 2, 30, 44, 5, 36, 17, 8, 90, 10};
        Arrays.sort(arr);
        System.out.print("Enter number to search: ");
        int key = sc.nextInt();
       int index=BSearch(arr, key);
       if(index==-1)
       {
        System.out.println("Number not Found!");
       }
       else{System.out.println("Number found at index:"+ index);}
       sc.close();
    }
    public static int BSearch(int []arr,int key)
    {
        int start =0;
        int end = arr.length;

        while(start<=end)
        {
            int mid=(start+end)/2;
            if(key==arr[mid])
            return mid;
            else if (key>arr[mid])
            start=mid+1;
            else end=mid-1;
         }
         return  -1;
    }
}
