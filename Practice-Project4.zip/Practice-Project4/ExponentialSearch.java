import java.util.Scanner;
public class ExponentialSearch {
    public static int exponentialSearch(int[] array, int Key) {
        int length = array.length;
        
        if (array[0] == Key) {
            return 0;
        }
        
        int range = 1;
        while (range < length && array[range] <=Key) {
            range *= 2;
        }
        
     
        int left = range / 2;
        int right = Math.min(range, length - 1);
        
        while (left <= right) {
            int mid = left + (right - left) / 2;
            
            if (array[mid] == Key) {
                return mid;
            } else if (array[mid] < Key) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] array = {2, 5, 9, 12, 18, 21, 25};
        System.out.print("Enter a Number to Search: ");
        int Key = sc.nextInt();
        int result = exponentialSearch(array, Key);
        
        if (result == -1) {
            System.out.println("Key value not found in the array.");
        } else {
            System.out.println("Key value found at index: " + result);
        }
        sc.close();
    }
}
